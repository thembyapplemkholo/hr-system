﻿Public Class EMPLOYEES_LEAVE_INFORMATION

    Private Sub EmployeeTBLBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles EmployeeTBLBindingNavigatorSaveItem.Click
        MsgBox("EMPLOYEE 'S LEAVE SUCCESSFULLY RECORDED")
        Me.Validate()
        Me.EmployeeTBLBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.HrDBDataSet3)

    End Sub

    Private Sub EMPLOYEES_LEAVE_INFORMATION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HrDBDataSet3.employeeTBL' table. You can move, or remove it, as needed.
        Me.EmployeeTBLTableAdapter.Fill(Me.HrDBDataSet3.employeeTBL)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        MsgBox("ADDING NEW EMPLOYEE'S LEAVE RECORD")
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
        MsgBox("EMPLOYEE'S LEAVE RECORD SUCCESSFULLY DELETED")
    End Sub
End Class