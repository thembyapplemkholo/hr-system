﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EPLOYEES_INFORMATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Emp_CodeLabel As System.Windows.Forms.Label
        Dim Emp_NameLabel As System.Windows.Forms.Label
        Dim Emp_SurnameLabel As System.Windows.Forms.Label
        Dim Emp_DOBLabel As System.Windows.Forms.Label
        Dim Emp_StartDateLabel As System.Windows.Forms.Label
        Dim Emp_EndDateLabel As System.Windows.Forms.Label
        Dim Emp_GenderLabel As System.Windows.Forms.Label
        Dim Emp_Marital_StatusLabel As System.Windows.Forms.Label
        Dim Emp_AddressLabel As System.Windows.Forms.Label
        Dim Emp_PhoneNoLabel As System.Windows.Forms.Label
        Dim Emp_EmailLabel As System.Windows.Forms.Label
        Dim Job_CodeLabel As System.Windows.Forms.Label
        Dim Section_IDLabel As System.Windows.Forms.Label
        Dim ID_NumberLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EPLOYEES_INFORMATION))
        Me.HrDBDataSet1 = New HR_System_Nkambule_SM.hrDBDataSet1()
        Me.EmployeeTBLBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeTBLTableAdapter = New HR_System_Nkambule_SM.hrDBDataSet1TableAdapters.employeeTBLTableAdapter()
        Me.TableAdapterManager = New HR_System_Nkambule_SM.hrDBDataSet1TableAdapters.TableAdapterManager()
        Me.EmployeeTBLBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeTBLBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Emp_CodeTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_SurnameTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_DOBDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Emp_StartDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Emp_EndDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Emp_GenderTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_Marital_StatusTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_AddressTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_PhoneNoTextBox = New System.Windows.Forms.TextBox()
        Me.Emp_EmailTextBox = New System.Windows.Forms.TextBox()
        Me.Job_CodeTextBox = New System.Windows.Forms.TextBox()
        Me.Section_IDTextBox = New System.Windows.Forms.TextBox()
        Me.ID_NumberTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Emp_CodeLabel = New System.Windows.Forms.Label()
        Emp_NameLabel = New System.Windows.Forms.Label()
        Emp_SurnameLabel = New System.Windows.Forms.Label()
        Emp_DOBLabel = New System.Windows.Forms.Label()
        Emp_StartDateLabel = New System.Windows.Forms.Label()
        Emp_EndDateLabel = New System.Windows.Forms.Label()
        Emp_GenderLabel = New System.Windows.Forms.Label()
        Emp_Marital_StatusLabel = New System.Windows.Forms.Label()
        Emp_AddressLabel = New System.Windows.Forms.Label()
        Emp_PhoneNoLabel = New System.Windows.Forms.Label()
        Emp_EmailLabel = New System.Windows.Forms.Label()
        Job_CodeLabel = New System.Windows.Forms.Label()
        Section_IDLabel = New System.Windows.Forms.Label()
        ID_NumberLabel = New System.Windows.Forms.Label()
        CType(Me.HrDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EmployeeTBLBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'Emp_CodeLabel
        '
        Emp_CodeLabel.AutoSize = True
        Emp_CodeLabel.Location = New System.Drawing.Point(59, 42)
        Emp_CodeLabel.Name = "Emp_CodeLabel"
        Emp_CodeLabel.Size = New System.Drawing.Size(59, 13)
        Emp_CodeLabel.TabIndex = 1
        Emp_CodeLabel.Text = "Emp Code:"
        '
        'Emp_NameLabel
        '
        Emp_NameLabel.AutoSize = True
        Emp_NameLabel.Location = New System.Drawing.Point(59, 68)
        Emp_NameLabel.Name = "Emp_NameLabel"
        Emp_NameLabel.Size = New System.Drawing.Size(62, 13)
        Emp_NameLabel.TabIndex = 3
        Emp_NameLabel.Text = "Emp Name:"
        '
        'Emp_SurnameLabel
        '
        Emp_SurnameLabel.AutoSize = True
        Emp_SurnameLabel.Location = New System.Drawing.Point(59, 94)
        Emp_SurnameLabel.Name = "Emp_SurnameLabel"
        Emp_SurnameLabel.Size = New System.Drawing.Size(76, 13)
        Emp_SurnameLabel.TabIndex = 5
        Emp_SurnameLabel.Text = "Emp Surname:"
        '
        'Emp_DOBLabel
        '
        Emp_DOBLabel.AutoSize = True
        Emp_DOBLabel.Location = New System.Drawing.Point(59, 121)
        Emp_DOBLabel.Name = "Emp_DOBLabel"
        Emp_DOBLabel.Size = New System.Drawing.Size(57, 13)
        Emp_DOBLabel.TabIndex = 7
        Emp_DOBLabel.Text = "Emp DOB:"
        '
        'Emp_StartDateLabel
        '
        Emp_StartDateLabel.AutoSize = True
        Emp_StartDateLabel.Location = New System.Drawing.Point(59, 147)
        Emp_StartDateLabel.Name = "Emp_StartDateLabel"
        Emp_StartDateLabel.Size = New System.Drawing.Size(82, 13)
        Emp_StartDateLabel.TabIndex = 9
        Emp_StartDateLabel.Text = "Emp Start Date:"
        '
        'Emp_EndDateLabel
        '
        Emp_EndDateLabel.AutoSize = True
        Emp_EndDateLabel.Location = New System.Drawing.Point(59, 173)
        Emp_EndDateLabel.Name = "Emp_EndDateLabel"
        Emp_EndDateLabel.Size = New System.Drawing.Size(79, 13)
        Emp_EndDateLabel.TabIndex = 11
        Emp_EndDateLabel.Text = "Emp End Date:"
        '
        'Emp_GenderLabel
        '
        Emp_GenderLabel.AutoSize = True
        Emp_GenderLabel.Location = New System.Drawing.Point(59, 198)
        Emp_GenderLabel.Name = "Emp_GenderLabel"
        Emp_GenderLabel.Size = New System.Drawing.Size(69, 13)
        Emp_GenderLabel.TabIndex = 13
        Emp_GenderLabel.Text = "Emp Gender:"
        '
        'Emp_Marital_StatusLabel
        '
        Emp_Marital_StatusLabel.AutoSize = True
        Emp_Marital_StatusLabel.Location = New System.Drawing.Point(59, 224)
        Emp_Marital_StatusLabel.Name = "Emp_Marital_StatusLabel"
        Emp_Marital_StatusLabel.Size = New System.Drawing.Size(98, 13)
        Emp_Marital_StatusLabel.TabIndex = 15
        Emp_Marital_StatusLabel.Text = "Emp Marital Status:"
        '
        'Emp_AddressLabel
        '
        Emp_AddressLabel.AutoSize = True
        Emp_AddressLabel.Location = New System.Drawing.Point(59, 250)
        Emp_AddressLabel.Name = "Emp_AddressLabel"
        Emp_AddressLabel.Size = New System.Drawing.Size(72, 13)
        Emp_AddressLabel.TabIndex = 17
        Emp_AddressLabel.Text = "Emp Address:"
        '
        'Emp_PhoneNoLabel
        '
        Emp_PhoneNoLabel.AutoSize = True
        Emp_PhoneNoLabel.Location = New System.Drawing.Point(59, 276)
        Emp_PhoneNoLabel.Name = "Emp_PhoneNoLabel"
        Emp_PhoneNoLabel.Size = New System.Drawing.Size(82, 13)
        Emp_PhoneNoLabel.TabIndex = 19
        Emp_PhoneNoLabel.Text = "Emp Phone No:"
        '
        'Emp_EmailLabel
        '
        Emp_EmailLabel.AutoSize = True
        Emp_EmailLabel.Location = New System.Drawing.Point(59, 302)
        Emp_EmailLabel.Name = "Emp_EmailLabel"
        Emp_EmailLabel.Size = New System.Drawing.Size(59, 13)
        Emp_EmailLabel.TabIndex = 21
        Emp_EmailLabel.Text = "Emp Email:"
        '
        'Job_CodeLabel
        '
        Job_CodeLabel.AutoSize = True
        Job_CodeLabel.Location = New System.Drawing.Point(59, 328)
        Job_CodeLabel.Name = "Job_CodeLabel"
        Job_CodeLabel.Size = New System.Drawing.Size(55, 13)
        Job_CodeLabel.TabIndex = 23
        Job_CodeLabel.Text = "Job Code:"
        '
        'Section_IDLabel
        '
        Section_IDLabel.AutoSize = True
        Section_IDLabel.Location = New System.Drawing.Point(59, 354)
        Section_IDLabel.Name = "Section_IDLabel"
        Section_IDLabel.Size = New System.Drawing.Size(60, 13)
        Section_IDLabel.TabIndex = 25
        Section_IDLabel.Text = "Section ID:"
        '
        'ID_NumberLabel
        '
        ID_NumberLabel.AutoSize = True
        ID_NumberLabel.Location = New System.Drawing.Point(59, 380)
        ID_NumberLabel.Name = "ID_NumberLabel"
        ID_NumberLabel.Size = New System.Drawing.Size(61, 13)
        ID_NumberLabel.TabIndex = 27
        ID_NumberLabel.Text = "ID Number:"
        '
        'HrDBDataSet1
        '
        Me.HrDBDataSet1.DataSetName = "hrDBDataSet1"
        Me.HrDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTBLBindingSource
        '
        Me.EmployeeTBLBindingSource.DataMember = "employeeTBL"
        Me.EmployeeTBLBindingSource.DataSource = Me.HrDBDataSet1
        '
        'EmployeeTBLTableAdapter
        '
        Me.EmployeeTBLTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.employeeTBLTableAdapter = Me.EmployeeTBLTableAdapter
        Me.TableAdapterManager.UpdateOrder = HR_System_Nkambule_SM.hrDBDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeTBLBindingNavigator
        '
        Me.EmployeeTBLBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.EmployeeTBLBindingNavigator.BindingSource = Me.EmployeeTBLBindingSource
        Me.EmployeeTBLBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.EmployeeTBLBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.EmployeeTBLBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.EmployeeTBLBindingNavigatorSaveItem})
        Me.EmployeeTBLBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.EmployeeTBLBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.EmployeeTBLBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.EmployeeTBLBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.EmployeeTBLBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.EmployeeTBLBindingNavigator.Name = "EmployeeTBLBindingNavigator"
        Me.EmployeeTBLBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.EmployeeTBLBindingNavigator.Size = New System.Drawing.Size(450, 25)
        Me.EmployeeTBLBindingNavigator.TabIndex = 0
        Me.EmployeeTBLBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'EmployeeTBLBindingNavigatorSaveItem
        '
        Me.EmployeeTBLBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EmployeeTBLBindingNavigatorSaveItem.Image = CType(resources.GetObject("EmployeeTBLBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.EmployeeTBLBindingNavigatorSaveItem.Name = "EmployeeTBLBindingNavigatorSaveItem"
        Me.EmployeeTBLBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.EmployeeTBLBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Emp_CodeTextBox
        '
        Me.Emp_CodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Code", True))
        Me.Emp_CodeTextBox.Location = New System.Drawing.Point(163, 39)
        Me.Emp_CodeTextBox.Name = "Emp_CodeTextBox"
        Me.Emp_CodeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_CodeTextBox.TabIndex = 2
        '
        'Emp_NameTextBox
        '
        Me.Emp_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Name", True))
        Me.Emp_NameTextBox.Location = New System.Drawing.Point(163, 65)
        Me.Emp_NameTextBox.Name = "Emp_NameTextBox"
        Me.Emp_NameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_NameTextBox.TabIndex = 4
        '
        'Emp_SurnameTextBox
        '
        Me.Emp_SurnameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Surname", True))
        Me.Emp_SurnameTextBox.Location = New System.Drawing.Point(163, 91)
        Me.Emp_SurnameTextBox.Name = "Emp_SurnameTextBox"
        Me.Emp_SurnameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_SurnameTextBox.TabIndex = 6
        '
        'Emp_DOBDateTimePicker
        '
        Me.Emp_DOBDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.EmployeeTBLBindingSource, "Emp_DOB", True))
        Me.Emp_DOBDateTimePicker.Location = New System.Drawing.Point(163, 117)
        Me.Emp_DOBDateTimePicker.Name = "Emp_DOBDateTimePicker"
        Me.Emp_DOBDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Emp_DOBDateTimePicker.TabIndex = 8
        '
        'Emp_StartDateDateTimePicker
        '
        Me.Emp_StartDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.EmployeeTBLBindingSource, "Emp_StartDate", True))
        Me.Emp_StartDateDateTimePicker.Location = New System.Drawing.Point(163, 143)
        Me.Emp_StartDateDateTimePicker.Name = "Emp_StartDateDateTimePicker"
        Me.Emp_StartDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Emp_StartDateDateTimePicker.TabIndex = 10
        '
        'Emp_EndDateDateTimePicker
        '
        Me.Emp_EndDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.EmployeeTBLBindingSource, "Emp_EndDate", True))
        Me.Emp_EndDateDateTimePicker.Location = New System.Drawing.Point(163, 169)
        Me.Emp_EndDateDateTimePicker.Name = "Emp_EndDateDateTimePicker"
        Me.Emp_EndDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Emp_EndDateDateTimePicker.TabIndex = 12
        '
        'Emp_GenderTextBox
        '
        Me.Emp_GenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Gender", True))
        Me.Emp_GenderTextBox.Location = New System.Drawing.Point(163, 195)
        Me.Emp_GenderTextBox.Name = "Emp_GenderTextBox"
        Me.Emp_GenderTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_GenderTextBox.TabIndex = 14
        '
        'Emp_Marital_StatusTextBox
        '
        Me.Emp_Marital_StatusTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Marital_Status", True))
        Me.Emp_Marital_StatusTextBox.Location = New System.Drawing.Point(163, 221)
        Me.Emp_Marital_StatusTextBox.Name = "Emp_Marital_StatusTextBox"
        Me.Emp_Marital_StatusTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_Marital_StatusTextBox.TabIndex = 16
        '
        'Emp_AddressTextBox
        '
        Me.Emp_AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Address", True))
        Me.Emp_AddressTextBox.Location = New System.Drawing.Point(163, 247)
        Me.Emp_AddressTextBox.Name = "Emp_AddressTextBox"
        Me.Emp_AddressTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_AddressTextBox.TabIndex = 18
        '
        'Emp_PhoneNoTextBox
        '
        Me.Emp_PhoneNoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_PhoneNo", True))
        Me.Emp_PhoneNoTextBox.Location = New System.Drawing.Point(163, 273)
        Me.Emp_PhoneNoTextBox.Name = "Emp_PhoneNoTextBox"
        Me.Emp_PhoneNoTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_PhoneNoTextBox.TabIndex = 20
        '
        'Emp_EmailTextBox
        '
        Me.Emp_EmailTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Email", True))
        Me.Emp_EmailTextBox.Location = New System.Drawing.Point(163, 299)
        Me.Emp_EmailTextBox.Name = "Emp_EmailTextBox"
        Me.Emp_EmailTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_EmailTextBox.TabIndex = 22
        '
        'Job_CodeTextBox
        '
        Me.Job_CodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Job_Code", True))
        Me.Job_CodeTextBox.Location = New System.Drawing.Point(163, 325)
        Me.Job_CodeTextBox.Name = "Job_CodeTextBox"
        Me.Job_CodeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Job_CodeTextBox.TabIndex = 24
        '
        'Section_IDTextBox
        '
        Me.Section_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Section_ID", True))
        Me.Section_IDTextBox.Location = New System.Drawing.Point(163, 351)
        Me.Section_IDTextBox.Name = "Section_IDTextBox"
        Me.Section_IDTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Section_IDTextBox.TabIndex = 26
        '
        'ID_NumberTextBox
        '
        Me.ID_NumberTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "ID_Number", True))
        Me.ID_NumberTextBox.Location = New System.Drawing.Point(163, 377)
        Me.ID_NumberTextBox.Name = "ID_NumberTextBox"
        Me.ID_NumberTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ID_NumberTextBox.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(258, 460)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 29
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'EPLOYEES_INFORMATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(450, 495)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Emp_CodeLabel)
        Me.Controls.Add(Me.Emp_CodeTextBox)
        Me.Controls.Add(Emp_NameLabel)
        Me.Controls.Add(Me.Emp_NameTextBox)
        Me.Controls.Add(Emp_SurnameLabel)
        Me.Controls.Add(Me.Emp_SurnameTextBox)
        Me.Controls.Add(Emp_DOBLabel)
        Me.Controls.Add(Me.Emp_DOBDateTimePicker)
        Me.Controls.Add(Emp_StartDateLabel)
        Me.Controls.Add(Me.Emp_StartDateDateTimePicker)
        Me.Controls.Add(Emp_EndDateLabel)
        Me.Controls.Add(Me.Emp_EndDateDateTimePicker)
        Me.Controls.Add(Emp_GenderLabel)
        Me.Controls.Add(Me.Emp_GenderTextBox)
        Me.Controls.Add(Emp_Marital_StatusLabel)
        Me.Controls.Add(Me.Emp_Marital_StatusTextBox)
        Me.Controls.Add(Emp_AddressLabel)
        Me.Controls.Add(Me.Emp_AddressTextBox)
        Me.Controls.Add(Emp_PhoneNoLabel)
        Me.Controls.Add(Me.Emp_PhoneNoTextBox)
        Me.Controls.Add(Emp_EmailLabel)
        Me.Controls.Add(Me.Emp_EmailTextBox)
        Me.Controls.Add(Job_CodeLabel)
        Me.Controls.Add(Me.Job_CodeTextBox)
        Me.Controls.Add(Section_IDLabel)
        Me.Controls.Add(Me.Section_IDTextBox)
        Me.Controls.Add(ID_NumberLabel)
        Me.Controls.Add(Me.ID_NumberTextBox)
        Me.Controls.Add(Me.EmployeeTBLBindingNavigator)
        Me.Name = "EPLOYEES_INFORMATION"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EMPLOYEES INFORMATION CAPTURE"
        CType(Me.HrDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EmployeeTBLBindingNavigator.ResumeLayout(False)
        Me.EmployeeTBLBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HrDBDataSet1 As HR_System_Nkambule_SM.hrDBDataSet1
    Friend WithEvents EmployeeTBLBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeeTBLTableAdapter As HR_System_Nkambule_SM.hrDBDataSet1TableAdapters.employeeTBLTableAdapter
    Friend WithEvents TableAdapterManager As HR_System_Nkambule_SM.hrDBDataSet1TableAdapters.TableAdapterManager
    Friend WithEvents EmployeeTBLBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EmployeeTBLBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Emp_CodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_SurnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_DOBDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents Emp_StartDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents Emp_EndDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents Emp_GenderTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_Marital_StatusTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_AddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_PhoneNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Emp_EmailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Job_CodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Section_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ID_NumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
