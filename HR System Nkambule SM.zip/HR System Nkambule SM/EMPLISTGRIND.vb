﻿Public Class EMPLISTGRIND

    Private Sub EmployeeTBLBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.EmployeeTBLBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.HrDBDataSet1)

    End Sub

    Private Sub EMPLISTGRIND_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HrDBDataSet1.employeeTBL' table. You can move, or remove it, as needed.
        Me.EmployeeTBLTableAdapter.Fill(Me.HrDBDataSet1.employeeTBL)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("Now printing make sure you printer is turned on and connected to the computer")
        PrintDocument1.Print()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Email.Show()
    End Sub
End Class