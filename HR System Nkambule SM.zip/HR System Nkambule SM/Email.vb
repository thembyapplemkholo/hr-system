﻿Imports System.Net.Mail
Public Class Email

    Private Sub Email_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim SMTPcl As New SmtpClient
            Dim SendMail As New MailMessage()
            Dim Email As String = "thembyapplemkholo@gmail.com"
            Dim Passwordss As String = "9110106039082.."
            SMTPcl.UseDefaultCredentials = False
            SMTPcl.Credentials = New Net.NetworkCredential(Email, Passwordss)
            SMTPcl.Port = 587
            SMTPcl.EnableSsl = True
            SMTPcl.Host = "smtp.gmail.com"

            SendMail = New MailMessage()
            SendMail.From = New MailAddress(txtFrom.Text)
            SendMail.To.Add(txtTo.Text)
            SendMail.Subject = "HR Reply"
            SendMail.IsBodyHtml = False
            SendMail.Body = txtMessage.Text
            SMTPcl.Send(SendMail)
            MsgBox("E-mail sent successfully")

        Catch MassError As Exception
            MsgBox(MassError.ToString)
        End Try

    End Sub
End Class