﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PERFORMANCEDETAILS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Emp_CodeLabel As System.Windows.Forms.Label
        Dim Review_IDLabel As System.Windows.Forms.Label
        Dim Review_By_Emp_IDLabel As System.Windows.Forms.Label
        Dim Comment_By_ReviewLabel As System.Windows.Forms.Label
        Dim Comment_by_EmployeeLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PERFORMANCEDETAILS))
        Me.HrDBDataSet2 = New HR_System_Nkambule_SM.hrDBDataSet2()
        Me.EmployeeTBLBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeTBLTableAdapter = New HR_System_Nkambule_SM.hrDBDataSet2TableAdapters.employeeTBLTableAdapter()
        Me.TableAdapterManager = New HR_System_Nkambule_SM.hrDBDataSet2TableAdapters.TableAdapterManager()
        Me.EmployeeTBLBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeTBLBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Emp_CodeTextBox = New System.Windows.Forms.TextBox()
        Me.Review_IDTextBox = New System.Windows.Forms.TextBox()
        Me.Review_By_Emp_IDTextBox = New System.Windows.Forms.TextBox()
        Me.Comment_By_ReviewTextBox = New System.Windows.Forms.TextBox()
        Me.Comment_by_EmployeeTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Emp_CodeLabel = New System.Windows.Forms.Label()
        Review_IDLabel = New System.Windows.Forms.Label()
        Review_By_Emp_IDLabel = New System.Windows.Forms.Label()
        Comment_By_ReviewLabel = New System.Windows.Forms.Label()
        Comment_by_EmployeeLabel = New System.Windows.Forms.Label()
        CType(Me.HrDBDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EmployeeTBLBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'Emp_CodeLabel
        '
        Emp_CodeLabel.AutoSize = True
        Emp_CodeLabel.Location = New System.Drawing.Point(35, 43)
        Emp_CodeLabel.Name = "Emp_CodeLabel"
        Emp_CodeLabel.Size = New System.Drawing.Size(59, 13)
        Emp_CodeLabel.TabIndex = 1
        Emp_CodeLabel.Text = "Emp Code:"
        '
        'Review_IDLabel
        '
        Review_IDLabel.AutoSize = True
        Review_IDLabel.Location = New System.Drawing.Point(35, 69)
        Review_IDLabel.Name = "Review_IDLabel"
        Review_IDLabel.Size = New System.Drawing.Size(60, 13)
        Review_IDLabel.TabIndex = 3
        Review_IDLabel.Text = "Review ID:"
        '
        'Review_By_Emp_IDLabel
        '
        Review_By_Emp_IDLabel.AutoSize = True
        Review_By_Emp_IDLabel.Location = New System.Drawing.Point(35, 95)
        Review_By_Emp_IDLabel.Name = "Review_By_Emp_IDLabel"
        Review_By_Emp_IDLabel.Size = New System.Drawing.Size(99, 13)
        Review_By_Emp_IDLabel.TabIndex = 5
        Review_By_Emp_IDLabel.Text = "Review By-Emp ID:"
        '
        'Comment_By_ReviewLabel
        '
        Comment_By_ReviewLabel.AutoSize = True
        Comment_By_ReviewLabel.Location = New System.Drawing.Point(35, 121)
        Comment_By_ReviewLabel.Name = "Comment_By_ReviewLabel"
        Comment_By_ReviewLabel.Size = New System.Drawing.Size(108, 13)
        Comment_By_ReviewLabel.TabIndex = 7
        Comment_By_ReviewLabel.Text = "Comment By Review:"
        '
        'Comment_by_EmployeeLabel
        '
        Comment_by_EmployeeLabel.AutoSize = True
        Comment_by_EmployeeLabel.Location = New System.Drawing.Point(35, 189)
        Comment_by_EmployeeLabel.Name = "Comment_by_EmployeeLabel"
        Comment_by_EmployeeLabel.Size = New System.Drawing.Size(117, 13)
        Comment_by_EmployeeLabel.TabIndex = 9
        Comment_by_EmployeeLabel.Text = "Comment by Employee:"
        '
        'HrDBDataSet2
        '
        Me.HrDBDataSet2.DataSetName = "hrDBDataSet2"
        Me.HrDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTBLBindingSource
        '
        Me.EmployeeTBLBindingSource.DataMember = "employeeTBL"
        Me.EmployeeTBLBindingSource.DataSource = Me.HrDBDataSet2
        '
        'EmployeeTBLTableAdapter
        '
        Me.EmployeeTBLTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.employeeTBLTableAdapter = Me.EmployeeTBLTableAdapter
        Me.TableAdapterManager.UpdateOrder = HR_System_Nkambule_SM.hrDBDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeTBLBindingNavigator
        '
        Me.EmployeeTBLBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.EmployeeTBLBindingNavigator.BindingSource = Me.EmployeeTBLBindingSource
        Me.EmployeeTBLBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.EmployeeTBLBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.EmployeeTBLBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.EmployeeTBLBindingNavigatorSaveItem})
        Me.EmployeeTBLBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.EmployeeTBLBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.EmployeeTBLBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.EmployeeTBLBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.EmployeeTBLBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.EmployeeTBLBindingNavigator.Name = "EmployeeTBLBindingNavigator"
        Me.EmployeeTBLBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.EmployeeTBLBindingNavigator.Size = New System.Drawing.Size(375, 25)
        Me.EmployeeTBLBindingNavigator.TabIndex = 0
        Me.EmployeeTBLBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'EmployeeTBLBindingNavigatorSaveItem
        '
        Me.EmployeeTBLBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EmployeeTBLBindingNavigatorSaveItem.Image = CType(resources.GetObject("EmployeeTBLBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.EmployeeTBLBindingNavigatorSaveItem.Name = "EmployeeTBLBindingNavigatorSaveItem"
        Me.EmployeeTBLBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.EmployeeTBLBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Emp_CodeTextBox
        '
        Me.Emp_CodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Code", True))
        Me.Emp_CodeTextBox.Location = New System.Drawing.Point(158, 40)
        Me.Emp_CodeTextBox.Name = "Emp_CodeTextBox"
        Me.Emp_CodeTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Emp_CodeTextBox.TabIndex = 2
        '
        'Review_IDTextBox
        '
        Me.Review_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Review_ID", True))
        Me.Review_IDTextBox.Location = New System.Drawing.Point(158, 66)
        Me.Review_IDTextBox.Name = "Review_IDTextBox"
        Me.Review_IDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Review_IDTextBox.TabIndex = 4
        '
        'Review_By_Emp_IDTextBox
        '
        Me.Review_By_Emp_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Review_By-Emp_ID", True))
        Me.Review_By_Emp_IDTextBox.Location = New System.Drawing.Point(158, 92)
        Me.Review_By_Emp_IDTextBox.Name = "Review_By_Emp_IDTextBox"
        Me.Review_By_Emp_IDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Review_By_Emp_IDTextBox.TabIndex = 6
        '
        'Comment_By_ReviewTextBox
        '
        Me.Comment_By_ReviewTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Comment_By_Review", True))
        Me.Comment_By_ReviewTextBox.Location = New System.Drawing.Point(158, 118)
        Me.Comment_By_ReviewTextBox.Multiline = True
        Me.Comment_By_ReviewTextBox.Name = "Comment_By_ReviewTextBox"
        Me.Comment_By_ReviewTextBox.Size = New System.Drawing.Size(151, 62)
        Me.Comment_By_ReviewTextBox.TabIndex = 8
        '
        'Comment_by_EmployeeTextBox
        '
        Me.Comment_by_EmployeeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Comment_by_Employee", True))
        Me.Comment_by_EmployeeTextBox.Location = New System.Drawing.Point(158, 186)
        Me.Comment_by_EmployeeTextBox.Multiline = True
        Me.Comment_by_EmployeeTextBox.Name = "Comment_by_EmployeeTextBox"
        Me.Comment_by_EmployeeTextBox.Size = New System.Drawing.Size(151, 73)
        Me.Comment_by_EmployeeTextBox.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(204, 269)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PERFORMANCEDETAILS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(375, 304)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Emp_CodeLabel)
        Me.Controls.Add(Me.Emp_CodeTextBox)
        Me.Controls.Add(Review_IDLabel)
        Me.Controls.Add(Me.Review_IDTextBox)
        Me.Controls.Add(Review_By_Emp_IDLabel)
        Me.Controls.Add(Me.Review_By_Emp_IDTextBox)
        Me.Controls.Add(Comment_By_ReviewLabel)
        Me.Controls.Add(Me.Comment_By_ReviewTextBox)
        Me.Controls.Add(Comment_by_EmployeeLabel)
        Me.Controls.Add(Me.Comment_by_EmployeeTextBox)
        Me.Controls.Add(Me.EmployeeTBLBindingNavigator)
        Me.Name = "PERFORMANCEDETAILS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PERFORMANCEDETAILS"
        CType(Me.HrDBDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EmployeeTBLBindingNavigator.ResumeLayout(False)
        Me.EmployeeTBLBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HrDBDataSet2 As HR_System_Nkambule_SM.hrDBDataSet2
    Friend WithEvents EmployeeTBLBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeeTBLTableAdapter As HR_System_Nkambule_SM.hrDBDataSet2TableAdapters.employeeTBLTableAdapter
    Friend WithEvents TableAdapterManager As HR_System_Nkambule_SM.hrDBDataSet2TableAdapters.TableAdapterManager
    Friend WithEvents EmployeeTBLBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EmployeeTBLBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Emp_CodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Review_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Review_By_Emp_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Comment_By_ReviewTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Comment_by_EmployeeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
