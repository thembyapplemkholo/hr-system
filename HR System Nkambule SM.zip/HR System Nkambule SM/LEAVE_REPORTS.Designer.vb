﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LEAVE_REPORTS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.HrDBDataSet3 = New HR_System_Nkambule_SM.hrDBDataSet3()
        Me.EmployeeTBLBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeTBLTableAdapter = New HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.employeeTBLTableAdapter()
        Me.TableAdapterManager = New HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager()
        Me.EmployeeTBLDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        CType(Me.HrDBDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HrDBDataSet3
        '
        Me.HrDBDataSet3.DataSetName = "hrDBDataSet3"
        Me.HrDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTBLBindingSource
        '
        Me.EmployeeTBLBindingSource.DataMember = "employeeTBL"
        Me.EmployeeTBLBindingSource.DataSource = Me.HrDBDataSet3
        '
        'EmployeeTBLTableAdapter
        '
        Me.EmployeeTBLTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.employeeTBLTableAdapter = Me.EmployeeTBLTableAdapter
        Me.TableAdapterManager.UpdateOrder = HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeTBLDataGridView
        '
        Me.EmployeeTBLDataGridView.AutoGenerateColumns = False
        Me.EmployeeTBLDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.EmployeeTBLDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.EmployeeTBLDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.EmployeeTBLDataGridView.DataSource = Me.EmployeeTBLBindingSource
        Me.EmployeeTBLDataGridView.Location = New System.Drawing.Point(35, 28)
        Me.EmployeeTBLDataGridView.Name = "EmployeeTBLDataGridView"
        Me.EmployeeTBLDataGridView.Size = New System.Drawing.Size(541, 259)
        Me.EmployeeTBLDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Emp_Code"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Emp_Code"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Leave_ID"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Leave_ID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Leave_Type"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Leave_Type"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Leave_Credit"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Leave_Credit"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Leave_Date"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Leave_Date"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(105, 306)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(115, 23)
        Me.Button3.TabIndex = 7
        Me.Button3.Text = "EMAIL RECORDS"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(264, 306)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(98, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "PRINT"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(394, 306)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PrintDocument1
        '
        Me.PrintDocument1.OriginAtMargins = True
        '
        'LEAVE_REPORTS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(611, 341)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.EmployeeTBLDataGridView)
        Me.Name = "LEAVE_REPORTS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LEAVE_REPORTS"
        CType(Me.HrDBDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents HrDBDataSet3 As HR_System_Nkambule_SM.hrDBDataSet3
    Friend WithEvents EmployeeTBLBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeeTBLTableAdapter As HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.employeeTBLTableAdapter
    Friend WithEvents TableAdapterManager As HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager
    Friend WithEvents EmployeeTBLDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
End Class
