﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EMPLOYEES_LEAVE_INFORMATION
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Emp_CodeLabel As System.Windows.Forms.Label
        Dim Leave_IDLabel As System.Windows.Forms.Label
        Dim Leave_TypeLabel As System.Windows.Forms.Label
        Dim Leave_CreditLabel As System.Windows.Forms.Label
        Dim Leave_DateLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EMPLOYEES_LEAVE_INFORMATION))
        Me.HrDBDataSet3 = New HR_System_Nkambule_SM.hrDBDataSet3()
        Me.EmployeeTBLBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmployeeTBLTableAdapter = New HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.employeeTBLTableAdapter()
        Me.TableAdapterManager = New HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager()
        Me.EmployeeTBLBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EmployeeTBLBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Emp_CodeTextBox = New System.Windows.Forms.TextBox()
        Me.Leave_IDTextBox = New System.Windows.Forms.TextBox()
        Me.Leave_TypeTextBox = New System.Windows.Forms.TextBox()
        Me.Leave_CreditTextBox = New System.Windows.Forms.TextBox()
        Me.Leave_DateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Button1 = New System.Windows.Forms.Button()
        Emp_CodeLabel = New System.Windows.Forms.Label()
        Leave_IDLabel = New System.Windows.Forms.Label()
        Leave_TypeLabel = New System.Windows.Forms.Label()
        Leave_CreditLabel = New System.Windows.Forms.Label()
        Leave_DateLabel = New System.Windows.Forms.Label()
        CType(Me.HrDBDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EmployeeTBLBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'Emp_CodeLabel
        '
        Emp_CodeLabel.AutoSize = True
        Emp_CodeLabel.Location = New System.Drawing.Point(33, 56)
        Emp_CodeLabel.Name = "Emp_CodeLabel"
        Emp_CodeLabel.Size = New System.Drawing.Size(59, 13)
        Emp_CodeLabel.TabIndex = 1
        Emp_CodeLabel.Text = "Emp Code:"
        '
        'Leave_IDLabel
        '
        Leave_IDLabel.AutoSize = True
        Leave_IDLabel.Location = New System.Drawing.Point(33, 82)
        Leave_IDLabel.Name = "Leave_IDLabel"
        Leave_IDLabel.Size = New System.Drawing.Size(54, 13)
        Leave_IDLabel.TabIndex = 3
        Leave_IDLabel.Text = "Leave ID:"
        '
        'Leave_TypeLabel
        '
        Leave_TypeLabel.AutoSize = True
        Leave_TypeLabel.Location = New System.Drawing.Point(33, 108)
        Leave_TypeLabel.Name = "Leave_TypeLabel"
        Leave_TypeLabel.Size = New System.Drawing.Size(67, 13)
        Leave_TypeLabel.TabIndex = 5
        Leave_TypeLabel.Text = "Leave Type:"
        '
        'Leave_CreditLabel
        '
        Leave_CreditLabel.AutoSize = True
        Leave_CreditLabel.Location = New System.Drawing.Point(33, 134)
        Leave_CreditLabel.Name = "Leave_CreditLabel"
        Leave_CreditLabel.Size = New System.Drawing.Size(70, 13)
        Leave_CreditLabel.TabIndex = 7
        Leave_CreditLabel.Text = "Leave Credit:"
        '
        'Leave_DateLabel
        '
        Leave_DateLabel.AutoSize = True
        Leave_DateLabel.Location = New System.Drawing.Point(33, 161)
        Leave_DateLabel.Name = "Leave_DateLabel"
        Leave_DateLabel.Size = New System.Drawing.Size(66, 13)
        Leave_DateLabel.TabIndex = 9
        Leave_DateLabel.Text = "Leave Date:"
        '
        'HrDBDataSet3
        '
        Me.HrDBDataSet3.DataSetName = "hrDBDataSet3"
        Me.HrDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTBLBindingSource
        '
        Me.EmployeeTBLBindingSource.DataMember = "employeeTBL"
        Me.EmployeeTBLBindingSource.DataSource = Me.HrDBDataSet3
        '
        'EmployeeTBLTableAdapter
        '
        Me.EmployeeTBLTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.employeeTBLTableAdapter = Me.EmployeeTBLTableAdapter
        Me.TableAdapterManager.UpdateOrder = HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeTBLBindingNavigator
        '
        Me.EmployeeTBLBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.EmployeeTBLBindingNavigator.BindingSource = Me.EmployeeTBLBindingSource
        Me.EmployeeTBLBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.EmployeeTBLBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.EmployeeTBLBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.EmployeeTBLBindingNavigatorSaveItem})
        Me.EmployeeTBLBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.EmployeeTBLBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.EmployeeTBLBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.EmployeeTBLBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.EmployeeTBLBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.EmployeeTBLBindingNavigator.Name = "EmployeeTBLBindingNavigator"
        Me.EmployeeTBLBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.EmployeeTBLBindingNavigator.Size = New System.Drawing.Size(376, 25)
        Me.EmployeeTBLBindingNavigator.TabIndex = 0
        Me.EmployeeTBLBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'EmployeeTBLBindingNavigatorSaveItem
        '
        Me.EmployeeTBLBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EmployeeTBLBindingNavigatorSaveItem.Image = CType(resources.GetObject("EmployeeTBLBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.EmployeeTBLBindingNavigatorSaveItem.Name = "EmployeeTBLBindingNavigatorSaveItem"
        Me.EmployeeTBLBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.EmployeeTBLBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Emp_CodeTextBox
        '
        Me.Emp_CodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Emp_Code", True))
        Me.Emp_CodeTextBox.Location = New System.Drawing.Point(109, 53)
        Me.Emp_CodeTextBox.Name = "Emp_CodeTextBox"
        Me.Emp_CodeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Emp_CodeTextBox.TabIndex = 2
        '
        'Leave_IDTextBox
        '
        Me.Leave_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Leave_ID", True))
        Me.Leave_IDTextBox.Location = New System.Drawing.Point(109, 79)
        Me.Leave_IDTextBox.Name = "Leave_IDTextBox"
        Me.Leave_IDTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Leave_IDTextBox.TabIndex = 4
        '
        'Leave_TypeTextBox
        '
        Me.Leave_TypeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Leave_Type", True))
        Me.Leave_TypeTextBox.Location = New System.Drawing.Point(109, 105)
        Me.Leave_TypeTextBox.Name = "Leave_TypeTextBox"
        Me.Leave_TypeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Leave_TypeTextBox.TabIndex = 6
        '
        'Leave_CreditTextBox
        '
        Me.Leave_CreditTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeTBLBindingSource, "Leave_Credit", True))
        Me.Leave_CreditTextBox.Location = New System.Drawing.Point(109, 131)
        Me.Leave_CreditTextBox.Name = "Leave_CreditTextBox"
        Me.Leave_CreditTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Leave_CreditTextBox.TabIndex = 8
        '
        'Leave_DateDateTimePicker
        '
        Me.Leave_DateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.EmployeeTBLBindingSource, "Leave_Date", True))
        Me.Leave_DateDateTimePicker.Location = New System.Drawing.Point(109, 157)
        Me.Leave_DateDateTimePicker.Name = "Leave_DateDateTimePicker"
        Me.Leave_DateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Leave_DateDateTimePicker.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(204, 221)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "EXIT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'EMPLOYEES_LEAVE_INFORMATION
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(376, 273)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Emp_CodeLabel)
        Me.Controls.Add(Me.Emp_CodeTextBox)
        Me.Controls.Add(Leave_IDLabel)
        Me.Controls.Add(Me.Leave_IDTextBox)
        Me.Controls.Add(Leave_TypeLabel)
        Me.Controls.Add(Me.Leave_TypeTextBox)
        Me.Controls.Add(Leave_CreditLabel)
        Me.Controls.Add(Me.Leave_CreditTextBox)
        Me.Controls.Add(Leave_DateLabel)
        Me.Controls.Add(Me.Leave_DateDateTimePicker)
        Me.Controls.Add(Me.EmployeeTBLBindingNavigator)
        Me.Name = "EMPLOYEES_LEAVE_INFORMATION"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EMPLOYEES_LEAVE_INFORMATION"
        CType(Me.HrDBDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeTBLBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EmployeeTBLBindingNavigator.ResumeLayout(False)
        Me.EmployeeTBLBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HrDBDataSet3 As HR_System_Nkambule_SM.hrDBDataSet3
    Friend WithEvents EmployeeTBLBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeeTBLTableAdapter As HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.employeeTBLTableAdapter
    Friend WithEvents TableAdapterManager As HR_System_Nkambule_SM.hrDBDataSet3TableAdapters.TableAdapterManager
    Friend WithEvents EmployeeTBLBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EmployeeTBLBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Emp_CodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Leave_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Leave_TypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Leave_CreditTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Leave_DateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
