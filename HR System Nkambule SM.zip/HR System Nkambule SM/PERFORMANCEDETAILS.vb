﻿Public Class PERFORMANCEDETAILS

    Private Sub EmployeeTBLBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles EmployeeTBLBindingNavigatorSaveItem.Click
        MsgBox("EMPLOYEE 'S PERFOMANCE SUCESSFULLY RECORDED")
        Me.Validate()
        Me.EmployeeTBLBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.HrDBDataSet2)

    End Sub

    Private Sub PERFORMANCEDETAILS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HrDBDataSet2.employeeTBL' table. You can move, or remove it, as needed.
        Me.EmployeeTBLTableAdapter.Fill(Me.HrDBDataSet2.employeeTBL)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
        MsgBox("EMPLOYEE'S PERFOMANCE RECORD SUCESSFULLY DELETED")
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        MsgBox("ADDING NEW EMPLOYEE'S PERFOMANCE RECORD")
    End Sub
End Class