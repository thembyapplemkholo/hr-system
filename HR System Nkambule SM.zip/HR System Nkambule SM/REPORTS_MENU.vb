﻿Public Class REPORTS_MENU

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        EMPLISTGRIND.Show()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        PERFOMANCE_REPORTS.Show()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        LEAVE_REPORTS.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        SKILLS_REPORT.Show()
    End Sub

    Private Sub REPORTS_MENU_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class