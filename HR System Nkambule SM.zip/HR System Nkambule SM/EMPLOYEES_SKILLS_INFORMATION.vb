﻿Public Class EMPLOYEES_SKILLS_INFORMATION

    Private Sub EmployeeTBLBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles EmployeeTBLBindingNavigatorSaveItem.Click
        MsgBox("EMPLOYEE 'S SKILLS SUCCESSFULLY RECORDED")
        Me.Validate()
        Me.EmployeeTBLBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.HrDBDataSet4)

    End Sub

    Private Sub EMPLOYEES_SKILLS_INFORMATION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HrDBDataSet4.employeeTBL' table. You can move, or remove it, as needed.
        Me.EmployeeTBLTableAdapter.Fill(Me.HrDBDataSet4.employeeTBL)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
        MsgBox("EMPLOYEE'S SKILLS RECORD SUCCESSFULLY DELETED")
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        MsgBox("ADDING NEW EMPLOYEE'SKILLS RECORD")
    End Sub
End Class