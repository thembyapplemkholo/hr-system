﻿Public Class User_interface

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text <> "hr123456" Then
            MsgBox("Sorry incorrect user name please try again!!!")
        End If
        Dim passwd As String
        passwd = "emp123456"
        If TextBox2.Text <> passwd Then
            MsgBox("Sorry incorrect Password please try again!!!")
        ElseIf TextBox1.Text = "hr123456" Then
            HR_MENU.Show()
        End If

    End Sub

    Private Sub BTNABOUT_Click(sender As Object, e As EventArgs) Handles BTNABOUT.Click
        ABOUTDEV.SHOW()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub User_interface_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class